# Meu Financeiro

Aplicativo web de controle financeiro pessoal, em um único arquivo (`index.html`), sem dependências e sem servidor.

## Funcionalidades

- Dashboard com períodos (hoje, semana, mês, 3 meses, ano) e comparação com o período anterior
- Lançamentos de receitas e despesas, com contas, recorrência de 12 meses e marcação de pago/pendente
- Busca instantânea e filtros por tipo e conta
- Categorias com limites mensais e alertas
- Metas (caixinhas) com barra de progresso, prazo e imagem
- Gráficos de evolução e de despesas por categoria, maiores despesas e histórico de 6 meses
- Importação de extrato CSV, exportação CSV, backup e restauração em JSON
- Modo ocultar valores, tema escuro/claro e trava com PIN de 6 dígitos
- Ícones em SVG, sem emojis; animações leves em CSS que respeitam `prefers-reduced-motion`

## Como usar

Abra `index.html` no navegador. Para publicar online, ative o GitHub Pages em **Settings > Pages > Source: GitHub Actions**; o workflow em `.github/workflows/pages.yml` publica a cada push na branch `main`.

## Dados e segurança

Os dados ficam apenas no `localStorage` do navegador. Use **Configurações > Salvar backup** com frequência. O PIN é uma trava local de privacidade, não uma proteção criptográfica dos dados.
